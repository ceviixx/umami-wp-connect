<?php
define('UMAMI_CONNECT_DEFAULT_HOST', 'https://cloud.umami.is');
define('UMAMI_CONNECT_GITHUB_USER', 'ceviixx');
define('UMAMI_CONNECT_GITHUB_REPO', 'umami-wp-connect');